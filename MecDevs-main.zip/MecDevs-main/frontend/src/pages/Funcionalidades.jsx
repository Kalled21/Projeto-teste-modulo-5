

export default function Funcionalidades() {
    return (
        <>
            <main>
                <h1>teste</h1>
            </main>
        </>
    );
}

